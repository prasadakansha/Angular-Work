import { Component, OnInit } from '@angular/core';
import { Booking } from '../Model/Booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-view-all-bookings',
  templateUrl: './view-all-bookings.component.html',
  styleUrls: ['./view-all-bookings.component.css']
})
export class ViewAllBookingsComponent implements OnInit {

  bookings:Booking[]=[];
  __bookingService:BookingService;
  
constructor(__bookingService:BookingService)
{
  this.__bookingService=__bookingService;

}
  ngOnInit(): void {
    
  }
  view(bookingform)
  {
    this.__bookingService.fetchAllBookings().subscribe(booking=>{this.bookings=booking});
    console.log(this.bookings);
  }
  
}
