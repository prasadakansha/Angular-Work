import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Booking } from './Model/Booking';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  client:HttpClient ;
  constructor(client:HttpClient ){
  this.client=client;
  }
  
  baseBookingUrl="http://localhost:8087/bookings";

  addBookings(addBookings:Booking): Observable<Booking>{
   let url=this.baseBookingUrl+"/add";
   let result:Observable<Booking>= this.client.post<Booking>(url,addBookings);
   return result;
   }

 fetchAllBookings():Observable<Booking[]>
 {
   let url=this.baseBookingUrl+'/view/';
   let observable:Observable<Booking[]> =this.client.get<Booking[]>(url);
   return observable;
   
 }
 
 findBookingById(bookingId:number):Observable<Booking>{
   let url=this.baseBookingUrl+'/view/'+bookingId;
   let observable:Observable<Booking> =this.client.get<Booking>(url);
   return observable;  
 }
 deleteBookingById(bookingId:number){
  let url=this.baseBookingUrl+"/delete/"+bookingId;
  let result:Observable<void>=this.client.delete<void>(url);
  return result;
}
}
