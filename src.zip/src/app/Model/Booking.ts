import { User } from './User';
import { Passenger } from './Passenger';
import { Flight } from './Flight';


export class Booking
{
    bookingId:number;
    userId:User;
    bookingDate:Date;
    passengerList:Array<Passenger>;
    ticketCost:number;
    flightNumber:Flight;
    noOfPassenegers:number;
    constructor(
        bookingId:number,
    userId:User,
    bookingDate:Date,
    passengerList:Array<Passenger>,
    ticketCost:number,
    flightNumber:Flight,
    noOfPassenegers:number
    )
    {
this.bookingId=bookingId;
this.userId=userId;
this.bookingDate=bookingDate;
this.passengerList=passengerList;
this.ticketCost=ticketCost;
this.flightNumber=flightNumber;
this.noOfPassenegers=noOfPassenegers
    }

}