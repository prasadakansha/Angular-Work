export class Flight
{
flightNumber:number;

constructor(
    flightNumber:number,   
)
{
this.flightNumber=flightNumber;
}
}