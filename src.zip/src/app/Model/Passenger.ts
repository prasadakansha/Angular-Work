

export class Passenger
{
passengerName:String;
passengerAge:number;
gender:String;
passengerUIN:number;

constructor(
    passengerName:String,
passengerAge:number,
gender:String,
passengerUIN:number
)
{
this.passengerName=passengerName;
this.passengerAge=passengerAge;
this.gender=gender;
this.passengerUIN=passengerUIN;
}
}