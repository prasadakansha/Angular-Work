export class User
{
    userPhone:number;
    userId:number;

constructor(
    userPhone:number,
    userId:number
)
{
this.userPhone=userPhone;
this.userId=userId;
}
}